using Stipple
using StippleUI
using Genie.Requests, Genie.Renderer, Genie.Router
using Images, Colors, FileIO, Plots,ImageMagick,Base64;

Genie.config.cors_headers["Access-Control-Allow-Origin"] = "*"
Genie.config.cors_headers["Access-Control-Allow-Headers"] = "Content-Type"
Genie.config.cors_headers["Access-Control-Allow-Methods"] = "GET,POST,PUT,DELETE,OPTIONS"
Genie.config.cors_allowed_origins = ["*"]

const FILE_PATH = "public/sample.jpg"
const FINAL_PATH = "final.jpg"
#const IMGPATH = "demo.png"

# CardDemo definition inheriting from ReactiveModel
# Base.@kwdef: that defines keyword based contructor of mutable struct
@reactive mutable struct Model <: ReactiveModel
    process_s3::R{Bool} = false
    process_s5::R{Bool} = false
    process_p3::R{Bool} = false
    process_p5::R{Bool} = false
    imageurl::R{String} = ""
end

model = Model |> init

sobel3_kernel_x = Array{Float64}([1 0 -1; 2 0 -2; 1 0 -1])
sobel3_kernel_y = Array{Float64}([1 2 1; 0 0 0; -1 -2 -1])

sobel5_kernel_x = Array{Float64}([2 2 4 2 2; 1 1 2 1 1; 0 0 0 0 0; -1 -1 -2 -1 -1; -2 -2 -4 -2 -2])
sobel5_kernel_y = Array{Float64}([2 1 0 -1 -2; 2 1 0 -1 -2;4 2 0 -2 -4; 2 1 0 -1 -2; 2 1 0 -1 -2])

prewitt3_kernel_x = Array{Float64}([5 5 5; -3 0 -3; -3 -3 -3])
prewitt3_kernel_y = Array{Float64}([5 -3 -3; 5 0 -3; 5 -3 -3])

prewitt5_kernel_x = Array{Float64}([9 9 9 9 9; 9 5 5 5 9; -7 -3 0 -3 -7; -7 -3 -3 -3 -7; -7 -7 -7 -7 -7])
prewitt5_kernel_y = Array{Float64}([9 9 -7 -7 -7; 9 5 -3 -3 -7; 9 5 0 -3 -7; 9 5 -3 -3 -7; 9 9 -7 -7 -7])

function sobel(img, kernel_x, kernel_y)
    edge_img = zeros(Gray{Float64}, size(img, 1), size(img, 2))
    for x = 1:size(edge_img, 1)-size(kernel_x, 1)
        for y = 1:size(edge_img, 2)-size(kernel_y, 2)
            gx = sum(
                Gray{
                    Float64,
                }.(@view img[x:x+size(kernel_x, 1)-1, y:y+size(kernel_y, 2)-1]) .*
                kernel_x,
            )
            gy = sum(
                Gray{
                    Float64,
                }.(@view img[x:x+size(kernel_x, 1)-1, y:y+size(kernel_y, 2)-1]) .*
                kernel_y,
            )
            edge_img[x+1, y+1] = hypot(gx, gy)
        end
    end
    return edge_img
end

on(model.process_s3) do _
    model.imageurl[] = ""
    @info "Working"

    img = FileIO.load(FILE_PATH)
    img_gray = Gray.(img)

    @info img_gray
    sobel_image = convert(Array{Float64}, img_gray)
   
    lastImage = clamp01nan.(sobel(sobel_image, sobel3_kernel_x, sobel3_kernel_y))
    save(joinpath(@__DIR__, "public", FINAL_PATH), lastImage)
    model.imageurl[] = "/$FINAL_PATH#$(Base.time())"

    @info model.imageurl[]
    if (model.process_s3[])
        model.process_s3[] = false
    end   
end

on(model.process_s5) do _
    model.imageurl[] = ""
    @info "Working"

    img = FileIO.load(FILE_PATH)
    img_gray = Gray.(img)

    @info img_gray
    sobel_image = convert(Array{Float64}, img_gray)
   
    lastImage = clamp01nan.(sobel(sobel_image, sobel5_kernel_x, sobel5_kernel_y))
    save(joinpath(@__DIR__, "public", FINAL_PATH), lastImage)
   
    model.imageurl[] = "/$FINAL_PATH#$(Base.time())"
    @info model.imageurl[]
    if (model.process_s5[])
        model.process_s5[] = false
    end       
end

on(model.process_p3) do _
    model.imageurl[] = ""
    @info "Working"

    img = FileIO.load(FILE_PATH)
    img_gray = Gray.(img)

    @info img_gray
    sobel_image = convert(Array{Float64}, img_gray)
   
    lastImage = clamp01nan.(sobel(sobel_image, prewitt3_kernel_x, prewitt3_kernel_y))
    save(joinpath(@__DIR__, "public", FINAL_PATH), lastImage)
   
    model.imageurl[] = "/$FINAL_PATH#$(Base.time())"
    @info model.imageurl[]
    if (model.process_p3[])
        model.process_p3[] = false
    end       
end

on(model.process_p5) do _
    model.imageurl[] = ""
    @info "Working"

    img = FileIO.load(FILE_PATH)
    img_gray = Gray.(img)

    @info img_gray
    sobel_image = convert(Array{Float64}, img_gray)
   
    lastImage = clamp01nan.(sobel(sobel_image, prewitt5_kernel_x, prewitt5_kernel_y))
    save(joinpath(@__DIR__, "public", FINAL_PATH), lastImage)
   
    model.imageurl[] = "/$FINAL_PATH#$(Base.time())"
    @info model.imageurl[]
    if (model.process_p5[])
        model.process_p5[] = false
    end       
end


function ui(model)
    [
        page( model,
            class = "container",
            title = "Card Demo",
            partial = true,
            [
                row( # row takes a tuple of cells. Creates a `div` HTML element with a CSS class named `row`.
                    cell([h1("Edge Detection Project")]),
                )
                row(
                    [
                        cell(class="st-module", [
                            h2("Initial Image"),
                            card(
                                class = "q-pa-md row items-start q-gutter-md",
                               
                                        uploader(
                                            label = "Upload Image",
                                            :auto__upload,
                                            :multiple,
                                            method = "POST",
                                            url = "http://localhost:8000/upload",
                                            field__name = "img",
                                        ),
                            
                            ),
                            row([
                                
                                card(btn("Sobel 3x3",color="primary", @click("process_s3 = true")),
                                btn("Sobel 5x5",color="primary", @click("process_s5 = true")),
                                btn("Prewitt 3x3", color="primary", @click("process_p3 = true")),
                                btn("Prewitt 5x5",color="primary", @click("process_p5 = true")),
                                )
                                
                            ])
                           
                        ])
                        cell(class="st-module", [
                            h2("Transformed Image"),
                            card(
                                class = "q-pa-md row items-start q-gutter-md",
                                quasar(:img, src=:imageurl, spinner__color="white", style="height: 300px; max-width: 350px")
                                #imageview(src=:imageurl, spinner__color="white", style="height: 250px; max-width: 250px")
                            ),
                        ])
                    ],
                )
            ],
        ),
    ]
end

route("/") do
    html(ui(model), context = @__MODULE__)
end


route("/upload", method = POST) do
    if infilespayload(:img)
        @info Requests.filename(filespayload(:img))
        
        open(FILE_PATH, "w") do io
            write(FILE_PATH, filespayload(:img).data)
        @info File
        end
    else
        @info "No image uploaded"
       
    end 
    Genie.Renderer.redirect(:get)
end

#isrunning(:webserver) || up()
