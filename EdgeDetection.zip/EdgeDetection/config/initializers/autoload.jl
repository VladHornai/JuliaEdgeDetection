# Optional flat/non-resource MVC folder structure
# push!(LOAD_PATH,  "controllers", "views", "views/layouts", "models")