using EdgeDetection, Test
# implement your tests here
@test 1 == 1
