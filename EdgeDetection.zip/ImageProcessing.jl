using Images, Colors, FileIO, Plots;
img = load("Lenna.png");
img_gray = Gray.(img);
sobel_image = convert(Array{Float64}, img_gray);
kernel_x =  Array{Float64}([1 0 -1; 2 0 -2; 1 0 -1]);
kernel_y =  Array{Float64}([1 2 1; 0 0 0; -1 -2 -1]);

plot(sobel_image)
function sobel(img)
    edge_img = zeros(Gray{Float64}, size(img, 1), size(img, 2));
    for x in 1:size(edge_img, 1) - size(kernel_x,1)
        for y in 1:size(edge_img, 2) - size(kernel_y,2)
            gx = sum(Gray{Float64}.(
                @view img[x:x+size(kernel_x,1)-1, y:y+size(kernel_y,2)-1]) .* kernel_x)
            gy = sum(Gray{Float64}.(
                    @view img[x:x+size(kernel_x,1)-1, y:y+size(kernel_y,2)-1]) .* kernel_y)
            edge_img[x+1, y+1] = hypot(gx, gy)
           
        end
    end
    return edge_img;
end
plot(img_gray)
last_image = sobel(sobel_image)
plot(last_image)